@echo off
setlocal
cd /d "%~dp0"

rem look upward for the bundled JBR (%~dp0 already ends with a backslash)
set "JBR="
if exist "%~dp0lib\jbr\bin\java.exe" set "JBR=%~dp0lib\jbr"
if not defined JBR if exist "%~dp0..\lib\jbr\bin\java.exe" set "JBR=%~dp0..\lib\jbr"
if not defined JBR if exist "%~dp0..\..\lib\jbr\bin\java.exe" set "JBR=%~dp0..\..\lib\jbr"
if not defined JBR if exist "%~dp0..\..\..\lib\jbr\bin\java.exe" set "JBR=%~dp0..\..\..\lib\jbr"

if defined JBR (
    set "JAVA_HOME=%JBR%"
    set "JAVA=%JBR%\bin\java.exe"
) else (
    if defined JAVA_HOME (
        set "JAVA=%JAVA_HOME%\bin\java.exe"
    ) else (
        set "JAVA=java"
    )
)

if not exist "app\mc\Main.class" (
    echo [ERROR] app\mc\Main.class not found - package looks broken.
    pause
    exit /b 1
)

echo Starting mc-launcher ...
"%JAVA%" -cp app mc.Main
if errorlevel 1 (
    echo.
    echo [ERROR] mc-launcher exited abnormally.
    pause
    exit /b 1
)