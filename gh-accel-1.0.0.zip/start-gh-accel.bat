@echo off
setlocal
cd /d "%~dp0"

rem look upward for Winllx's bundled JBR (%~dp0 already ends with a backslash)
set "JBR="
if exist "%~dp0lib\jbr\bin\java.exe" set "JBR=%~dp0lib\jbr"
if not defined JBR if exist "%~dp0..\lib\jbr\bin\java.exe" set "JBR=%~dp0..\lib\jbr"
if not defined JBR if exist "%~dp0..\..\lib\jbr\bin\java.exe" set "JBR=%~dp0..\..\lib\jbr"
if not defined JBR if exist "%~dp0..\..\..\lib\jbr\bin\java.exe" set "JBR=%~dp0..\..\..\lib\jbr"

set "JAVAW="
if defined JBR set "JAVAW=%JBR%\bin\javaw.exe"
if not defined JAVAW if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javaw.exe" set "JAVAW=%JAVA_HOME%\bin\javaw.exe"
if not defined JAVAW set "JAVAW=javaw"

if not exist "app\accel\Main.class" (
    echo [ERROR] app\accel\Main.class not found - package looks broken.
    pause
    exit /b 1
)

start "" "%JAVAW%" -cp app accel.Main
